package com.example.bibifba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibifbaApplicationTests {

	@Test
	void contextLoads() {
	}

}
